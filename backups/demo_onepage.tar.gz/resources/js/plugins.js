// @codekit-prepend quiet "bootstrap.js";
// @codekit-prepend quiet "gsdk-bootstrapswitch.js";
// @codekit-prepend quiet "jquery.bxslider.js";
// @codekit-prepend quiet "jquery.waypoints.min.js";
// @codekit-prepend quiet "modernizr.js";
// @codekit-prepend quiet "prettify.js";